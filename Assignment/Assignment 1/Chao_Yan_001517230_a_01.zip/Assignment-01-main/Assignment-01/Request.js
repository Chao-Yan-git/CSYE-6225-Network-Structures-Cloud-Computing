const request = require('request');

_EXTERNAL_URL = 'https://app.swaggerhub.com/apis-docs/spring2022-csye6225/app/a01';

const callExternalApiUsingRequest = (callback) => {
    request(_EXTERNAL_URL, { json: true }, (err, res, body) => {
        if (err) {
            return callback(err);
        }
        return callback(body);
    });
}

module.exports.callApi = callExternalApiUsingRequest;