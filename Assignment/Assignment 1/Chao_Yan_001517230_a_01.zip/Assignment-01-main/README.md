# Assignment 01

## Configuration
- cd Assignment-01
- npm install node express request

## Run the Project
node app.js then use postman to test http://localhost:3000/healthz
